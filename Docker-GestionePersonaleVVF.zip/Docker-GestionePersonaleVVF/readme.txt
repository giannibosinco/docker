docker build -t gestionepersonalevvf .

docker run -it -d --name gestionepersonalevvf -p 4000:8282 gestionepersonalevvf.
 